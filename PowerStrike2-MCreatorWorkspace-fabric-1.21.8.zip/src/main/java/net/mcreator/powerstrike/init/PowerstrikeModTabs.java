/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.powerstrike.PowerstrikeMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class PowerstrikeModTabs {
	public static ResourceKey<CreativeModeTab> TAB_POWER_STRIKE = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(PowerstrikeMod.MODID, "power_strike"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_POWER_STRIKE,
				CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0).title(Component.translatable("item_group.powerstrike.power_strike")).icon(() -> new ItemStack(PowerstrikeModItems.GAUNTET_PYRUS_SWORD)).displayItems((parameters, tabData) -> {
					tabData.accept(PowerstrikeModItems.GAUNTET_PYRUS_SWORD);
					tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD);
					tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS_SWORD);
					tabData.accept(PowerstrikeModItems.GAUNTLET_PYRUS);
					tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS);
					tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_BLAZE);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_BOOSTED_DRAGON);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_RAPID_FIRE);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_MAXIMUM_PYRUS);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_DESTROY_VANISH);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_BLACK_OUT);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_BIND_SHIELD);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_ATTRACTOR);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_AIR_BATTLE);
					tabData.accept(PowerstrikeModItems.ABILITY_CARD_FEATHER_STORM);
					tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS);
					tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS_SWORD);
					tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS);
					tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS_SWORD);
					tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA);
					tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA_SWORD);
				}).build());
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(tabData -> {
			tabData.accept(PowerstrikeModItems.GAUNTET_PYRUS_SWORD);
			tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD);
			tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS_SWORD);
			tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS_SWORD);
			tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS_SWORD);
			tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA_SWORD);
		});
	}
}