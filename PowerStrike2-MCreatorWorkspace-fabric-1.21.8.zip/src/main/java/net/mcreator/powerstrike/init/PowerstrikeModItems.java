/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.powerstrike.item.*;
import net.mcreator.powerstrike.PowerstrikeMod;

import java.util.function.Function;

public class PowerstrikeModItems {
	public static Item GAUNTET_PYRUS_SWORD;
	public static Item GAUNTLET_VENTUS_SWORD;
	public static Item GAUNTLET_DARKUS_SWORD;
	public static Item GAUNTLET_PYRUS;
	public static Item GAUNTLET_VENTUS;
	public static Item GAUNTLET_DARKUS;
	public static Item ABILITY_CARD_BLAZE;
	public static Item ABILITY_CARD_BOOSTED_DRAGON;
	public static Item ABILITY_CARD_RAPID_FIRE;
	public static Item ABILITY_CARD_MAXIMUM_PYRUS;
	public static Item ABILITY_CARD_DESTROY_VANISH;
	public static Item ABILITY_CARD_BLACK_OUT;
	public static Item ABILITY_CARD_BIND_SHIELD;
	public static Item ABILITY_CARD_ATTRACTOR;
	public static Item ABILITY_CARD_AIR_BATTLE;
	public static Item ABILITY_CARD_FEATHER_STORM;
	public static Item GAUNTLET_AQUOS;
	public static Item GAUNTLET_AQUOS_SWORD;
	public static Item GAUNTLET_HAOS;
	public static Item GAUNTLET_HAOS_SWORD;
	public static Item GAUNTLET_SUBTERRA;
	public static Item GAUNTLET_SUBTERRA_SWORD;

	public static void load() {
		GAUNTET_PYRUS_SWORD = register("gauntet_pyrus_sword", GauntetPyrusSwordItem::new);
		GAUNTLET_VENTUS_SWORD = register("gauntlet_ventus_sword", GauntletVentusSwordItem::new);
		GAUNTLET_DARKUS_SWORD = register("gauntlet_darkus_sword", GauntletDarkusSwordItem::new);
		GAUNTLET_PYRUS = register("gauntlet_pyrus", GauntletPyrusItem::new);
		GAUNTLET_VENTUS = register("gauntlet_ventus", GauntletVentusItem::new);
		GAUNTLET_DARKUS = register("gauntlet_darkus", GauntletDarkusItem::new);
		ABILITY_CARD_BLAZE = register("ability_card_blaze", AbilityCardBlazeItem::new);
		ABILITY_CARD_BOOSTED_DRAGON = register("ability_card_boosted_dragon", AbilityCardBoostedDragonItem::new);
		ABILITY_CARD_RAPID_FIRE = register("ability_card_rapid_fire", AbilityCardRapidFireItem::new);
		ABILITY_CARD_MAXIMUM_PYRUS = register("ability_card_maximum_pyrus", AbilityCardMaximumPyrusItem::new);
		ABILITY_CARD_DESTROY_VANISH = register("ability_card_destroy_vanish", AbilityCardDestroyVanishItem::new);
		ABILITY_CARD_BLACK_OUT = register("ability_card_black_out", AbilityCardBlackOutItem::new);
		ABILITY_CARD_BIND_SHIELD = register("ability_card_bind_shield", AbilityCardBindShieldItem::new);
		ABILITY_CARD_ATTRACTOR = register("ability_card_attractor", AbilityCardAttractorItem::new);
		ABILITY_CARD_AIR_BATTLE = register("ability_card_air_battle", AbilityCardAirBattleItem::new);
		ABILITY_CARD_FEATHER_STORM = register("ability_card_feather_storm", AbilityCardFeatherStormItem::new);
		GAUNTLET_AQUOS = register("gauntlet_aquos", GauntletAquosItem::new);
		GAUNTLET_AQUOS_SWORD = register("gauntlet_aquos_sword", GauntletAquosSwordItem::new);
		GAUNTLET_HAOS = register("gauntlet_haos", HaosGauntletItem::new);
		GAUNTLET_HAOS_SWORD = register("gauntlet_haos_sword", HaosGauntletSwordItem::new);
		GAUNTLET_SUBTERRA = register("gauntlet_subterra", GauntletSubterraItem::new);
		GAUNTLET_SUBTERRA_SWORD = register("gauntlet_subterra_sword", GauntletSubterraSwordItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(PowerstrikeMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}
}