/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.core.Holder;

import net.mcreator.powerstrike.potion.*;
import net.mcreator.powerstrike.PowerstrikeMod;

import java.util.function.Supplier;

public class PowerstrikeModMobEffects {
	public static Holder<MobEffect> ABILITY_MAXIMUM_PYRUS;
	public static Holder<MobEffect> ABILITY_BLAZE;
	public static Holder<MobEffect> ABILITY_BOOSTED_DRAGON;
	public static Holder<MobEffect> ABILITY_RAPID_FIRE;
	public static Holder<MobEffect> ABILITY_DESTROY_VANISH;
	public static Holder<MobEffect> ABILITY_BLACK_OUT;
	public static Holder<MobEffect> ABILITY_BIND_SHIELD;
	public static Holder<MobEffect> ABILITY_ATTRACTOR;
	public static Holder<MobEffect> ABILITY_AIR_BATTLE;
	public static Holder<MobEffect> ABILITY_FEATHER_STORM;

	public static void load() {
		ABILITY_MAXIMUM_PYRUS = register("ability_maximum_pyrus", AbilityMaximumPyrusMobEffect::new);
		ABILITY_BLAZE = register("ability_blaze", AbilityBlazeMobEffect::new);
		ABILITY_BOOSTED_DRAGON = register("ability_boosted_dragon", AbilityBoostedDragonMobEffect::new);
		ABILITY_RAPID_FIRE = register("ability_rapid_fire", AbilityRapidFireMobEffect::new);
		ABILITY_DESTROY_VANISH = register("ability_destroy_vanish", AbilityDestroyVanishMobEffect::new);
		ABILITY_BLACK_OUT = register("ability_black_out", AbilityBlackOutMobEffect::new);
		ABILITY_BIND_SHIELD = register("ability_bind_shield", AbilityBindShieldMobEffect::new);
		ABILITY_ATTRACTOR = register("ability_attractor", AbilityAttractorMobEffect::new);
		ABILITY_AIR_BATTLE = register("ability_air_battle", AbilityAirBattleMobEffect::new);
		ABILITY_FEATHER_STORM = register("ability_feather_storm", AbilityFeatherStormMobEffect::new);
	}

	private static Holder<MobEffect> register(String registryname, Supplier<MobEffect> element) {
		return Holder.direct(Registry.register(BuiltInRegistries.MOB_EFFECT, ResourceLocation.fromNamespaceAndPath(PowerstrikeMod.MODID, registryname), element.get()));
	}
}