package net.mcreator.powerstrike.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.powerstrike.init.PowerstrikeModMobEffects;
import net.mcreator.powerstrike.init.PowerstrikeModItems;
import net.mcreator.powerstrike.PowerstrikeMod;

public class GauntletBoostedDragonProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(PowerstrikeModMobEffects.ABILITY_BOOSTED_DRAGON)) {
			{
				Entity _shootFrom = entity;
				Level projectileLevel = _shootFrom.level();
				if (!projectileLevel.isClientSide()) {
					Projectile _entityToSpawn_2 = new LargeFireball(EntityType.FIREBALL, projectileLevel);
					_entityToSpawn_2.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
					_entityToSpawn_2.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 1, 0);
					projectileLevel.addFreshEntity(_entityToSpawn_2);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.firecharge.use")), SoundSource.HOSTILE, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("item.firecharge.use")), SoundSource.HOSTILE, 1, 1, false);
				}
			}
			if (entity instanceof Player _player) {
				_player.getCooldowns().addCooldown(itemstack, 10);
			}
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == PowerstrikeModItems.GAUNTLET_PYRUS) {
			if (entity.isShiftKeyDown()) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove9 = new ItemStack(PowerstrikeModItems.GAUNTLET_PYRUS);
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove9.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				PowerstrikeMod.queueServerWork(1, () -> {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack10 = new ItemStack(PowerstrikeModItems.GAUNTET_PYRUS_SWORD).copy();
						_setstack10.setCount(1);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack10);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				});
			}
		}
	}
}