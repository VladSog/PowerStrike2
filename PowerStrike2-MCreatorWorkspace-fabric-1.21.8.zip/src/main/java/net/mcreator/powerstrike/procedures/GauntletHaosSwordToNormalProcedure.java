package net.mcreator.powerstrike.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.init.PowerstrikeModItems;
import net.mcreator.powerstrike.PowerstrikeMod;

public class GauntletHaosSwordToNormalProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == PowerstrikeModItems.GAUNTLET_HAOS_SWORD) {
			if (entity.isShiftKeyDown()) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove3 = new ItemStack(PowerstrikeModItems.GAUNTLET_HAOS_SWORD);
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove3.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				PowerstrikeMod.queueServerWork(1, () -> {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack4 = new ItemStack(PowerstrikeModItems.GAUNTLET_HAOS).copy();
						_setstack4.setCount(1);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack4);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				});
			}
		}
	}
}