package net.mcreator.powerstrike.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;

import net.mcreator.powerstrike.init.PowerstrikeModMobEffects;
import net.mcreator.powerstrike.init.PowerstrikeModItems;

public class AbilityCardBlazeCheckGauntletProcedure {
	public static boolean eventResult = true;

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(PowerstrikeModMobEffects.ABILITY_MAXIMUM_PYRUS))) {
			if (!((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == PowerstrikeModItems.GAUNTET_PYRUS_SWORD)) {
				if (entity instanceof LivingEntity _entity) {
					_entity.removeEffect(MobEffects.HASTE);
					_entity.removeEffect(MobEffects.STRENGTH);
				}
			}
		}
	}
}