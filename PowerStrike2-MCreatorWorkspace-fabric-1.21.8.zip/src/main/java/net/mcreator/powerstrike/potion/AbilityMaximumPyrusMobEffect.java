package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityMaximumPyrusMobEffect extends MobEffect {
	public AbilityMaximumPyrusMobEffect() {
		super(MobEffectCategory.NEUTRAL, -65536);
	}
}