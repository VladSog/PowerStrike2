package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityAttractorMobEffect extends MobEffect {
	public AbilityAttractorMobEffect() {
		super(MobEffectCategory.NEUTRAL, -10092442);
	}
}