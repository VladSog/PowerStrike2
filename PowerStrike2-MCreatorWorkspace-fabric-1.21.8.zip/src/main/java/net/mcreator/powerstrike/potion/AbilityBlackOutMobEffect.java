package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityBlackOutMobEffect extends MobEffect {
	public AbilityBlackOutMobEffect() {
		super(MobEffectCategory.NEUTRAL, -10092442);
	}
}