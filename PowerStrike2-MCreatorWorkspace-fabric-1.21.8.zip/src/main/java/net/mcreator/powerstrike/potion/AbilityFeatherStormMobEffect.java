package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityFeatherStormMobEffect extends MobEffect {
	public AbilityFeatherStormMobEffect() {
		super(MobEffectCategory.NEUTRAL, -16724992);
	}
}