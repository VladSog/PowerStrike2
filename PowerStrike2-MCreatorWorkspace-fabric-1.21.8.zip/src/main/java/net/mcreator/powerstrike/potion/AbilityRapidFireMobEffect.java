package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityRapidFireMobEffect extends MobEffect {
	public AbilityRapidFireMobEffect() {
		super(MobEffectCategory.NEUTRAL, -65536);
	}
}