package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityBlazeMobEffect extends MobEffect {
	public AbilityBlazeMobEffect() {
		super(MobEffectCategory.NEUTRAL, -65536);
	}
}