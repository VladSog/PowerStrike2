package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityBindShieldMobEffect extends MobEffect {
	public AbilityBindShieldMobEffect() {
		super(MobEffectCategory.NEUTRAL, -1);
	}
}