package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityBoostedDragonMobEffect extends MobEffect {
	public AbilityBoostedDragonMobEffect() {
		super(MobEffectCategory.NEUTRAL, -65536);
	}
}