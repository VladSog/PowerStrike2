package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityDestroyVanishMobEffect extends MobEffect {
	public AbilityDestroyVanishMobEffect() {
		super(MobEffectCategory.NEUTRAL, -10092442);
	}
}