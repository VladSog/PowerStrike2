package net.mcreator.powerstrike.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AbilityAirBattleMobEffect extends MobEffect {
	public AbilityAirBattleMobEffect() {
		super(MobEffectCategory.NEUTRAL, -16724992);
	}
}