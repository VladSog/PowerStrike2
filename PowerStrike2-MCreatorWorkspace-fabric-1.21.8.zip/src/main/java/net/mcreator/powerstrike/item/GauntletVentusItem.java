package net.mcreator.powerstrike.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.procedures.VentusGauntletUseProcedure;

public class GauntletVentusItem extends Item {
	public GauntletVentusItem(Item.Properties properties) {
		super(properties.stacksTo(1).fireResistant());
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		VentusGauntletUseProcedure.execute(world, entity, entity.getItemInHand(hand));
		return ar;
	}
}