package net.mcreator.powerstrike.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.procedures.GauntletHaosUseProcedure;

public class HaosGauntletItem extends Item {
	public HaosGauntletItem(Item.Properties properties) {
		super(properties.stacksTo(1).fireResistant());
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		GauntletHaosUseProcedure.execute(world, entity);
		return ar;
	}
}