package net.mcreator.powerstrike.item;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.powerstrike.procedures.GauntetPyrusSwordToNormalProcedure;
import net.mcreator.powerstrike.procedures.GauntetPyrusSwordBlazeProcedure;

public class GauntetPyrusSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 0, 8f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("powerstrike:gauntet_pyrus_sword_repair_items")));

	public GauntetPyrusSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 13f, -2f).fireResistant().component(DataComponents.MAX_DAMAGE, null));
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		GauntetPyrusSwordToNormalProcedure.execute(world, entity);
		return ar;
	}

	@Override
	public void inventoryTick(ItemStack itemstack, ServerLevel world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
		super.inventoryTick(itemstack, world, entity, equipmentSlot);
		if (equipmentSlot == EquipmentSlot.MAINHAND)
			GauntetPyrusSwordBlazeProcedure.execute(entity);
	}
}