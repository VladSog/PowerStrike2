package net.mcreator.powerstrike.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.procedures.GauntletAquosUseProcedure;

public class GauntletAquosItem extends Item {
	public GauntletAquosItem() {
		super(new Item.Properties().stacksTo(1).fireResistant());
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		GauntletAquosUseProcedure.execute(world, entity);
		return ar;
	}
}