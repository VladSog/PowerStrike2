/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.powerstrike.item.*;
import net.mcreator.powerstrike.PowerstrikeMod;

public class PowerstrikeModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(PowerstrikeMod.MODID);
	public static final DeferredItem<Item> GAUNTET_PYRUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_VENTUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_DARKUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_PYRUS;
	public static final DeferredItem<Item> GAUNTLET_VENTUS;
	public static final DeferredItem<Item> GAUNTLET_DARKUS;
	public static final DeferredItem<Item> ABILITY_CARD_BLAZE;
	public static final DeferredItem<Item> ABILITY_CARD_BOOSTED_DRAGON;
	public static final DeferredItem<Item> ABILITY_CARD_RAPID_FIRE;
	public static final DeferredItem<Item> ABILITY_CARD_MAXIMUM_PYRUS;
	public static final DeferredItem<Item> ABILITY_CARD_DESTROY_VANISH;
	public static final DeferredItem<Item> ABILITY_CARD_BLACK_OUT;
	public static final DeferredItem<Item> ABILITY_CARD_BIND_SHIELD;
	public static final DeferredItem<Item> ABILITY_CARD_ATTRACTOR;
	public static final DeferredItem<Item> ABILITY_CARD_AIR_BATTLE;
	public static final DeferredItem<Item> ABILITY_CARD_FEATHER_STORM;
	public static final DeferredItem<Item> GAUNTLET_AQUOS;
	public static final DeferredItem<Item> GAUNTLET_AQUOS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_HAOS;
	public static final DeferredItem<Item> GAUNTLET_HAOS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_SUBTERRA;
	public static final DeferredItem<Item> GAUNTLET_SUBTERRA_SWORD;
	static {
		GAUNTET_PYRUS_SWORD = REGISTRY.register("gauntet_pyrus_sword", GauntetPyrusSwordItem::new);
		GAUNTLET_VENTUS_SWORD = REGISTRY.register("gauntlet_ventus_sword", GauntletVentusSwordItem::new);
		GAUNTLET_DARKUS_SWORD = REGISTRY.register("gauntlet_darkus_sword", GauntletDarkusSwordItem::new);
		GAUNTLET_PYRUS = REGISTRY.register("gauntlet_pyrus", GauntletPyrusItem::new);
		GAUNTLET_VENTUS = REGISTRY.register("gauntlet_ventus", GauntletVentusItem::new);
		GAUNTLET_DARKUS = REGISTRY.register("gauntlet_darkus", GauntletDarkusItem::new);
		ABILITY_CARD_BLAZE = REGISTRY.register("ability_card_blaze", AbilityCardBlazeItem::new);
		ABILITY_CARD_BOOSTED_DRAGON = REGISTRY.register("ability_card_boosted_dragon", AbilityCardBoostedDragonItem::new);
		ABILITY_CARD_RAPID_FIRE = REGISTRY.register("ability_card_rapid_fire", AbilityCardRapidFireItem::new);
		ABILITY_CARD_MAXIMUM_PYRUS = REGISTRY.register("ability_card_maximum_pyrus", AbilityCardMaximumPyrusItem::new);
		ABILITY_CARD_DESTROY_VANISH = REGISTRY.register("ability_card_destroy_vanish", AbilityCardDestroyVanishItem::new);
		ABILITY_CARD_BLACK_OUT = REGISTRY.register("ability_card_black_out", AbilityCardBlackOutItem::new);
		ABILITY_CARD_BIND_SHIELD = REGISTRY.register("ability_card_bind_shield", AbilityCardBindShieldItem::new);
		ABILITY_CARD_ATTRACTOR = REGISTRY.register("ability_card_attractor", AbilityCardAttractorItem::new);
		ABILITY_CARD_AIR_BATTLE = REGISTRY.register("ability_card_air_battle", AbilityCardAirBattleItem::new);
		ABILITY_CARD_FEATHER_STORM = REGISTRY.register("ability_card_feather_storm", AbilityCardFeatherStormItem::new);
		GAUNTLET_AQUOS = REGISTRY.register("gauntlet_aquos", GauntletAquosItem::new);
		GAUNTLET_AQUOS_SWORD = REGISTRY.register("gauntlet_aquos_sword", GauntletAquosSwordItem::new);
		GAUNTLET_HAOS = REGISTRY.register("gauntlet_haos", HaosGauntletItem::new);
		GAUNTLET_HAOS_SWORD = REGISTRY.register("gauntlet_haos_sword", HaosGauntletSwordItem::new);
		GAUNTLET_SUBTERRA = REGISTRY.register("gauntlet_subterra", GauntletSubterraItem::new);
		GAUNTLET_SUBTERRA_SWORD = REGISTRY.register("gauntlet_subterra_sword", GauntletSubterraSwordItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}