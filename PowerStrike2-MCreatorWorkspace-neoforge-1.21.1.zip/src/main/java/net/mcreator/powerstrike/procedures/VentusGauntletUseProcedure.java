package net.mcreator.powerstrike.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.init.PowerstrikeModMobEffects;
import net.mcreator.powerstrike.init.PowerstrikeModItems;
import net.mcreator.powerstrike.PowerstrikeMod;

public class VentusGauntletUseProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(PowerstrikeModMobEffects.ABILITY_AIR_BATTLE)) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 10, 7, false, false));
			if (entity instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack.getItem(), 160);
		}
		if (entity instanceof LivingEntity _livEnt4 && _livEnt4.hasEffect(PowerstrikeModMobEffects.ABILITY_FEATHER_STORM)) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 100, 5, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0, false, false));
			if (entity instanceof Player _player)
				_player.getCooldowns().addCooldown(itemstack.getItem(), 160);
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == PowerstrikeModItems.GAUNTLET_VENTUS.get()) {
			if (entity.isShiftKeyDown()) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(PowerstrikeModItems.GAUNTLET_VENTUS.get());
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				PowerstrikeMod.queueServerWork(1, () -> {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack15 = new ItemStack(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD.get()).copy();
						_setstack15.setCount(1);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack15);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				});
			}
		}
	}
}