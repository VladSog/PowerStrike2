package net.mcreator.powerstrike.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.powerstrike.init.PowerstrikeModMobEffects;

public class GauntetPyrusSwordBlazeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(PowerstrikeModMobEffects.ABILITY_BLAZE)) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED,
						entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(PowerstrikeModMobEffects.ABILITY_BLAZE) ? _livEnt.getEffect(PowerstrikeModMobEffects.ABILITY_BLAZE).getDuration() : 0, 1, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,
						entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(PowerstrikeModMobEffects.ABILITY_BLAZE) ? _livEnt.getEffect(PowerstrikeModMobEffects.ABILITY_BLAZE).getDuration() : 0, 1, false, false));
		} else {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DIG_SPEED);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.DAMAGE_BOOST);
		}
	}
}