package net.mcreator.powerstrike.item;

import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.powerstrike.procedures.GauntletVentusSwordToNormalProcedure;
import net.mcreator.powerstrike.init.PowerstrikeModItems;

@EventBusSubscriber
public class GauntletVentusSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 0, 9f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("powerstrike:gauntlet_ventus_sword_repair_items")));

	public GauntletVentusSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 13f, -2f).fireResistant());
	}

	@SubscribeEvent
	public static void modifyDefaultComponents(ModifyDefaultComponentsEvent event) {
		event.modify(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD.get(), builder -> builder.remove(DataComponents.MAX_DAMAGE));
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		GauntletVentusSwordToNormalProcedure.execute(world, entity);
		return ar;
	}
}