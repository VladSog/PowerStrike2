package net.mcreator.powerstrike.item;

import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.powerstrike.procedures.GauntletDarkusSwordToNormalProcedure;
import net.mcreator.powerstrike.procedures.GauntletDarkusSwordAttackProcedure;
import net.mcreator.powerstrike.init.PowerstrikeModItems;

@EventBusSubscriber
public class GauntletDarkusSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 0, 9f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("powerstrike:gauntlet_darkus_sword_repair_items")));

	public GauntletDarkusSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 13f, -2f));
	}

	@SubscribeEvent
	public static void modifyDefaultComponents(ModifyDefaultComponentsEvent event) {
		event.modify(PowerstrikeModItems.GAUNTLET_DARKUS_SWORD.get(), builder -> builder.remove(DataComponents.MAX_DAMAGE));
	}

	@Override
	public void hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		super.hurtEnemy(itemstack, entity, sourceentity);
		GauntletDarkusSwordAttackProcedure.execute(entity, sourceentity);
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		GauntletDarkusSwordToNormalProcedure.execute(world, entity);
		return ar;
	}
}