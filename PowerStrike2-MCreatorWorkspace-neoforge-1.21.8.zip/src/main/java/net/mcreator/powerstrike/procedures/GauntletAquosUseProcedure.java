package net.mcreator.powerstrike.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;

import net.mcreator.powerstrike.init.PowerstrikeModItems;
import net.mcreator.powerstrike.PowerstrikeMod;

public class GauntletAquosUseProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == PowerstrikeModItems.GAUNTLET_AQUOS.get()) {
			if (entity.isShiftKeyDown()) {
				if (entity instanceof Player _player) {
					ItemStack _stktoremove = new ItemStack(PowerstrikeModItems.GAUNTLET_AQUOS.get());
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
				PowerstrikeMod.queueServerWork(1, () -> {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack4 = new ItemStack(PowerstrikeModItems.GAUNTLET_AQUOS_SWORD.get()).copy();
						_setstack4.setCount(1);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack4);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				});
			}
		}
	}
}