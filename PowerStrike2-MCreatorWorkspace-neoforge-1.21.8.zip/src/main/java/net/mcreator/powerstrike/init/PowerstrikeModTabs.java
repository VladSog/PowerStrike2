/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.powerstrike.PowerstrikeMod;

@EventBusSubscriber
public class PowerstrikeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PowerstrikeMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> POWER_STRIKE = REGISTRY.register("power_strike",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.powerstrike.power_strike")).icon(() -> new ItemStack(PowerstrikeModItems.GAUNTET_PYRUS_SWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(PowerstrikeModItems.GAUNTET_PYRUS_SWORD.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS_SWORD.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_PYRUS.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_BLAZE.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_BOOSTED_DRAGON.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_RAPID_FIRE.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_MAXIMUM_PYRUS.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_DESTROY_VANISH.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_BLACK_OUT.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_BIND_SHIELD.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_ATTRACTOR.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_AIR_BATTLE.get());
				tabData.accept(PowerstrikeModItems.ABILITY_CARD_FEATHER_STORM.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS_SWORD.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS_SWORD.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA.get());
				tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA_SWORD.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(PowerstrikeModItems.GAUNTET_PYRUS_SWORD.get());
			tabData.accept(PowerstrikeModItems.GAUNTLET_VENTUS_SWORD.get());
			tabData.accept(PowerstrikeModItems.GAUNTLET_DARKUS_SWORD.get());
			tabData.accept(PowerstrikeModItems.GAUNTLET_AQUOS_SWORD.get());
			tabData.accept(PowerstrikeModItems.GAUNTLET_HAOS_SWORD.get());
			tabData.accept(PowerstrikeModItems.GAUNTLET_SUBTERRA_SWORD.get());
		}
	}
}