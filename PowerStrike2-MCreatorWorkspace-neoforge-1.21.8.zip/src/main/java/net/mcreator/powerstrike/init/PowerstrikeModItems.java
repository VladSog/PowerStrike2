/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.powerstrike.item.*;
import net.mcreator.powerstrike.PowerstrikeMod;

import java.util.function.Function;

public class PowerstrikeModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(PowerstrikeMod.MODID);
	public static final DeferredItem<Item> GAUNTET_PYRUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_VENTUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_DARKUS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_PYRUS;
	public static final DeferredItem<Item> GAUNTLET_VENTUS;
	public static final DeferredItem<Item> GAUNTLET_DARKUS;
	public static final DeferredItem<Item> ABILITY_CARD_BLAZE;
	public static final DeferredItem<Item> ABILITY_CARD_BOOSTED_DRAGON;
	public static final DeferredItem<Item> ABILITY_CARD_RAPID_FIRE;
	public static final DeferredItem<Item> ABILITY_CARD_MAXIMUM_PYRUS;
	public static final DeferredItem<Item> ABILITY_CARD_DESTROY_VANISH;
	public static final DeferredItem<Item> ABILITY_CARD_BLACK_OUT;
	public static final DeferredItem<Item> ABILITY_CARD_BIND_SHIELD;
	public static final DeferredItem<Item> ABILITY_CARD_ATTRACTOR;
	public static final DeferredItem<Item> ABILITY_CARD_AIR_BATTLE;
	public static final DeferredItem<Item> ABILITY_CARD_FEATHER_STORM;
	public static final DeferredItem<Item> GAUNTLET_AQUOS;
	public static final DeferredItem<Item> GAUNTLET_AQUOS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_HAOS;
	public static final DeferredItem<Item> GAUNTLET_HAOS_SWORD;
	public static final DeferredItem<Item> GAUNTLET_SUBTERRA;
	public static final DeferredItem<Item> GAUNTLET_SUBTERRA_SWORD;
	static {
		GAUNTET_PYRUS_SWORD = register("gauntet_pyrus_sword", GauntetPyrusSwordItem::new);
		GAUNTLET_VENTUS_SWORD = register("gauntlet_ventus_sword", GauntletVentusSwordItem::new);
		GAUNTLET_DARKUS_SWORD = register("gauntlet_darkus_sword", GauntletDarkusSwordItem::new);
		GAUNTLET_PYRUS = register("gauntlet_pyrus", GauntletPyrusItem::new);
		GAUNTLET_VENTUS = register("gauntlet_ventus", GauntletVentusItem::new);
		GAUNTLET_DARKUS = register("gauntlet_darkus", GauntletDarkusItem::new);
		ABILITY_CARD_BLAZE = register("ability_card_blaze", AbilityCardBlazeItem::new);
		ABILITY_CARD_BOOSTED_DRAGON = register("ability_card_boosted_dragon", AbilityCardBoostedDragonItem::new);
		ABILITY_CARD_RAPID_FIRE = register("ability_card_rapid_fire", AbilityCardRapidFireItem::new);
		ABILITY_CARD_MAXIMUM_PYRUS = register("ability_card_maximum_pyrus", AbilityCardMaximumPyrusItem::new);
		ABILITY_CARD_DESTROY_VANISH = register("ability_card_destroy_vanish", AbilityCardDestroyVanishItem::new);
		ABILITY_CARD_BLACK_OUT = register("ability_card_black_out", AbilityCardBlackOutItem::new);
		ABILITY_CARD_BIND_SHIELD = register("ability_card_bind_shield", AbilityCardBindShieldItem::new);
		ABILITY_CARD_ATTRACTOR = register("ability_card_attractor", AbilityCardAttractorItem::new);
		ABILITY_CARD_AIR_BATTLE = register("ability_card_air_battle", AbilityCardAirBattleItem::new);
		ABILITY_CARD_FEATHER_STORM = register("ability_card_feather_storm", AbilityCardFeatherStormItem::new);
		GAUNTLET_AQUOS = register("gauntlet_aquos", GauntletAquosItem::new);
		GAUNTLET_AQUOS_SWORD = register("gauntlet_aquos_sword", GauntletAquosSwordItem::new);
		GAUNTLET_HAOS = register("gauntlet_haos", HaosGauntletItem::new);
		GAUNTLET_HAOS_SWORD = register("gauntlet_haos_sword", HaosGauntletSwordItem::new);
		GAUNTLET_SUBTERRA = register("gauntlet_subterra", GauntletSubterraItem::new);
		GAUNTLET_SUBTERRA_SWORD = register("gauntlet_subterra_sword", GauntletSubterraSwordItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}
}