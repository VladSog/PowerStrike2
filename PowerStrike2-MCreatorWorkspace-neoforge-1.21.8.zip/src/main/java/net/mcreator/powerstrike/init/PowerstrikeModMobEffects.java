/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.powerstrike.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.powerstrike.potion.*;
import net.mcreator.powerstrike.PowerstrikeMod;

public class PowerstrikeModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, PowerstrikeMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_MAXIMUM_PYRUS = REGISTRY.register("ability_maximum_pyrus", () -> new AbilityMaximumPyrusMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_BLAZE = REGISTRY.register("ability_blaze", () -> new AbilityBlazeMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_BOOSTED_DRAGON = REGISTRY.register("ability_boosted_dragon", () -> new AbilityBoostedDragonMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_RAPID_FIRE = REGISTRY.register("ability_rapid_fire", () -> new AbilityRapidFireMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_DESTROY_VANISH = REGISTRY.register("ability_destroy_vanish", () -> new AbilityDestroyVanishMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_BLACK_OUT = REGISTRY.register("ability_black_out", () -> new AbilityBlackOutMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_BIND_SHIELD = REGISTRY.register("ability_bind_shield", () -> new AbilityBindShieldMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_ATTRACTOR = REGISTRY.register("ability_attractor", () -> new AbilityAttractorMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_AIR_BATTLE = REGISTRY.register("ability_air_battle", () -> new AbilityAirBattleMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> ABILITY_FEATHER_STORM = REGISTRY.register("ability_feather_storm", () -> new AbilityFeatherStormMobEffect());
}